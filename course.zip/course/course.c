/**
 * @file course.c
 * @author Sharmin Ahmed, Daniel Locke
 * @brief Functions to work with a class of students.
 * @version 1.0
 * @date 2022-04-05
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Allocates memory for a new student in the class and adds it.
 *
 * @param course The course which will take the new student.
 * @param student The new student to be added to the course.
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;

  //If the student is the first to be added, calloc is used for
  // memory allocation, otherwise realloc is used
  if (course->total_students == 1)
  {
    course->students = calloc(1, sizeof(Student));
  }
  else
  {
    course->students =
      realloc(course->students, course->total_students * sizeof(Student)); 
  }

  //Adding student to the course.
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints out the name, code, number of students and students in a course.
 *
 * @param course The course which is to be printed.
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");

  //Cycle through all students in the course and print them out.
  for (int i = 0; i < course->total_students; i++)
    print_student(&course->students[i]);
}

/**
 * @brief Function to determine the top student in a given course.
 *
 * @param course The course from which the highest average is being determined.
 * @return The student with the highest average.
 */
Student* top_student(Course* course)
{
  //There will be no top student if the class is empty.
  if (course->total_students == 0) return NULL;

  //Start by assuming that the first student has the highest average.
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];

  //Cycle through all remaining students, if they have a higher average
  //than the previous top student, they will be set as the top student.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }
  }

  return student;
}

/**
 * @brief Determines the number of passing students, and builds an array of those students.
 *
 * @param course The course from which the number of passing students is being determined.
 * @param total_passing a pointer who's value will be set to the new number of people passing the course.
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //For every student with an average of 50 or above, the number of passing students increases.
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  //Allocating memory to store all passing students in the array.
  passing = calloc(count, sizeof(Student));

  int j = 0;

  //Cycling through all students in the course and adding them to the passing array if they got a 50 or above.
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  //Reset the value of the given pointer to the new number of passing students.
  *total_passing = count;

  return passing;
}
