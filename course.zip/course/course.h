/**
 * @file course.h
 * @author Sharmin Ahmed, Daniel Locke
 * @brief Header file containing the declarations for course functions and struct.
 * @version 1.0
 * @date 2022-04-05
 */
#include "student.h"
#include <stdbool.h>

/**
 * @brief stucture for a course containing a name, course code, students and number of students.
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 * @brief Allocates memory for a new student in the class and adds it.
 *
 * @param course The course which will take the new student.
 * @param student The new student to be added to the course.
 */
void enroll_student(Course *course, Student *student);

/**
 * @brief Prints out the name, code, number of students and students in a course.
 *
 * @param course The course which is to be printed.
 */
void print_course(Course *course);

/**
 * @brief Function to determine the top student in a given course.
 *
 * @param course The course from which the highest average is being determined.
 * @return The student with the highest average.
 */
Student *top_student(Course* course);

/**
 * @brief Determines the number of passing students, and builds an array of those students.
 *
 * @param course The course from which the number of passing students is being determined.
 * @param total_passing a pointer who's value will be set to the new number of people passing the course.
 */
Student *passing(Course* course, int *total_passing);


