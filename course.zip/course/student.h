/**
 * @file student.h
 * @author Sharmin Ahmed, Daniel Locke
 * @brief Header file containing definitons for functions and student structure.
 * @version 1.0
 * @date 2022-04-05
 */ 

/**
 * @brief Structure for a student containg their first and last name, id, grade, and number of grades.
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
 * @brief Assigns a given grade to a given student.
 *
 * @param student The student which is getting a grade assigned.
 * @param grade The grade being assigned to the student.
 */
void add_grade(Student *student, double grade);

/**
 * @brief Calculates an average for a given student.
 *
 * @param student The student which is having their grade calculated.
 * @return The average of the students grades.
 */
double average(Student *student);

/**
 * @brief Prints out a student's name, id, grades, and average.
 *
 * @param student The student which has the details that are to be printed out.
 */
void print_student(Student *student);

/**
 * @brief Creates a random student with a given number of random grades.
 *
 * @param grades The number of grades the student will have.
 * @return The student with randomly generated properties.
 */
Student* generate_random_student(int grades); 
