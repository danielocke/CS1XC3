/**
 * @file student.c
 * @author Sharmin Ahmed, Daniel Locke
 * @brief A collection of functions to work with students.
 * @version 1.0
 * @date 2022-04-05
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Assigns a given grade to a given student.
 *
 * @param student The student which is getting a grade assigned.
 * @param grade The grade being assigned to the student.
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;

  //If it is the students first grade, using calloc to allocate room for one grade,
  //otherwise using realloc to reallocate memory for one more grade in the students grades.
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else
  {
    student->grades =
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Calculates an average for a given student.
 *
 * @param student The student which is having their grade calculated.
 * @return The average of the students grades.
 */
double average(Student* student)
{
  //Avoiding division by 0 if the student has no grades.
  if (student->num_grades == 0) return 0;

  double total = 0;

  //Summing all grades and dividing by the number of grades to find an average.
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief Prints out a student's name, id, grades, and average.
 *
 * @param student The student which has the details that are to be printed out.
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");

  //Cycling through all grades and printing them out.
  for (int i = 0; i < student->num_grades; i++)
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Creates a random student with a given number of random grades.
 *
 * @param grades The number of grades the student will have.
 * @return The student with randomly generated properties.
 */
Student* generate_random_student(int grades)
{
  //Possible first and last names for the student.
  char first_names[][24] =
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};

  //Allocating memory for a student.
  Student *new_student = calloc(1, sizeof(Student));

  //Assigning a random name to the new student.
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  //Generating a 10 digit student id string.
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  //Generating a number of random grades for the student equal to the input integer.
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}
