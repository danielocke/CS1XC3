var searchData=
[
  ['top_5fstudent',['top_student',['../course_8c.html#ae0130f7ef7b879c9a790ee27a5ce21b7',1,'top_student(Course *course):&#160;course.c'],['../course_8h.html#ae0130f7ef7b879c9a790ee27a5ce21b7',1,'top_student(Course *course):&#160;course.c']]]
];
